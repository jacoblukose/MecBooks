A Pen created at CodePen.io. You can find this one at http://codepen.io/simeydotme/pen/EaVxOa.

 A form with some interesting techniques... such as the placeholder animation and also the cutout legend in the fieldset.

Check out the error effects, too.

I imagine its fugly in IE8 and lower.